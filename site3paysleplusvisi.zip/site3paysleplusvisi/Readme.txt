Soto Axel
-J'ai fait 3 régles média queries pour les différents tailles d'écran 
elles ont pour but de s'adapter au différentes taille d'écran en ajustant le contenue pour qu'il ne soit pas illisible
-niveaux balises:-j ai mis une classe sur les images de mes différentes page .imgfr afin de toute les modifié en meme temps
		 -j ai mis un backgroud différents sur chaque pages grace aux id que jai mis sur leurs body
		 -j ai aussi utilisé la méme structure sur mes 3 differentes pages avec du display flex column sur mes div et j ai appliqué les méme classes
		 -j ai utilisé bootstrat pour ma nav j y ai ajouté un gradient de couleur et j y ai mis des images détouré de chaques pays concernés
		liste des balises:
			-acceuil:.def
				 #introt
				 #main
				 .backg
				 h1 h2
				 table th td
				 