## Draft 1.1

* Fix a few places where `color.change()` was incorrectly referred to as
  `color.scale()`.

## Draft 1

* Initial draft.
