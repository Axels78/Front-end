## Draft 1.1

* Replace floating-point wording for simply "number".

* Update integer return value range from `[1, $limit)` to `[1, $limit]`.

## Draft 1

* Initial draft.
