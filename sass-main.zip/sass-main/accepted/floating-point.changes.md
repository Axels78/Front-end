## Draft 1.2

* Add a section on the modulo operation.

## Draft 1.1

* Add a design decision section about the new math function semantics.

* Fix the definition of `math.$max-safe-integer` and `math.$min-safe-integer`.
  The listed values were correct, but the definitions were not.

## Draft 1

* Initial draft.
