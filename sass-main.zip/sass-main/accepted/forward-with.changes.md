## Draft 1.1

* Only `!default` variables defer to the pre-existing configuration.
