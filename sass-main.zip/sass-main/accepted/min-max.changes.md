## Draft 3

* Use `CssMinMax` instead of `MinMaxExpression` as a possibility for
  `CalcValue`. We don't want SassScript funtion invocations in plain CSS math
  functions.

## Draft 2

* Fix a typo where `CalcValue` was incorrectly referred to as `CalcArithemtic`.

## Draft 1

* Initial draft.
