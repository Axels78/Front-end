## Draft 3

* Make a potentially slash-separated number slash-free when passing it as an
  argument to a built-in function or mixin.

* Update the timeline.

## Draft 2

* Since the new module system has already launched, replace the top-level
  `slash-list()` and `divide()` functions with `list.slash()` and `math.div()`.

## Draft 1.1

* Require at least two arguments for `slash-list()`.

* Require that selector functions throw errors when passed slash-separated
  lists.

## Draft 1

* Initial draft.
