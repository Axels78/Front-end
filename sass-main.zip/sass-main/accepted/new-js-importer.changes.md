## Draft 1.1

* Add a section on canonicalizing relative URLs to the summary.

## Draft 1

* Initial draft.
