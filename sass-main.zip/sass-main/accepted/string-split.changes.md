## Draft 1.2

* Throw an error if `$limit` is 0.

## Draft 1.1

* Returns a bracketed list instead of an unbracketed one to be more clear
  about what type of value is being returned. 

## Draft 1

* Initial draft.
