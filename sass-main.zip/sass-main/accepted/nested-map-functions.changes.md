## Draft 1.1

* Changes `map.deep-remove()` to support passing a single key.
