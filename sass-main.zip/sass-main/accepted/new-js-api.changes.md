## Draft 3

* Use `"indented"` instead of `"sass"` to refer to the indented syntax.

## Draft 2.1

* Minor adjustments to link up with updates in the main spec.

## Draft 2

* Rename `CompileResult.includedUrls` to `CompileResult.loadedUrls`. This is
  better differentiated from the concept of `@include`ing mixins, and better
  aligned with the concept of loading modules.

## Draft 1

* Initial draft.
